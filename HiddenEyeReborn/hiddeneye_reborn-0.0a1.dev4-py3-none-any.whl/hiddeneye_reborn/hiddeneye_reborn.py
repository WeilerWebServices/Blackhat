
def main():
    print("Success, you can access this via terminal!")
    print("Hey, if you can - contact that lazy developer and make him code! Would be glad if you contribute, as well...")


if __name__ == "__main__":
    main()
